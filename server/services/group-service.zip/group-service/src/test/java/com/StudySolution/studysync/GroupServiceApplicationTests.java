package com.StudySolution.studysync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
